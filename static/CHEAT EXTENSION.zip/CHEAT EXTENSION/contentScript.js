function getSisaWaktu() {
    const element = document.getElementById("sisa-waktu");
    const form = document.getElementById("form-kerjakan");
    const questionText = document.querySelector("#isi-tes-soal p");
    const radioButtons = Array.from(document.querySelectorAll("input[type='radio'][name='soal-jawaban']"));
    const radioLabels = radioButtons.map(rb => rb.nextElementSibling.innerHTML);
    radioLabels.forEach((label, index) => {
        console.log(`  ${index + 1}. ${label}`);
    });

    const data = {
        element: element.innerHTML,
        questionText: questionText.innerHTML,
        radioButtons: radioButtons,
        radioLabels: radioLabels
    }

    if (data) {
        return data;
    } else {
        return null;
    }

}

function selectAnswer(answer) {
    const radioButtons = Array.from(document.querySelectorAll("input[type='radio'][name='soal-jawaban']"));

    radioButtons.forEach(rb => {
        const label = rb.nextElementSibling.innerHTML.trim();
        if (label === answer) {
            rb.checked = true;
        }
    });
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.action === "getSisaWaktu") {
        const questionDetails = getSisaWaktu();
        if (questionDetails) {
            chrome.runtime.sendMessage({ action: "sisaWaktu", value: questionDetails });
        }
    } else if (request.action === "selectAnswer") {
        selectAnswer(request.answer);
    }
});
