document.addEventListener("DOMContentLoaded", function () {
    const button = document.getElementById("get-sisa-waktu");
    button.addEventListener("click", function () {
        console.log("Generating...")
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "getSisaWaktu" });
        });

    });
});

function extractText(response) {
    let match = response.match(/#(.*?)#/);

    // Extract and print the result if hg dgf bwefwefwefwefsdf hbh a match is found
    let result = null;
    if (match) {
        result = match[1];

    } else {
        console.log("No match found");
    }
    return result

}

chrome.runtime.onMessage.addListener(async function (request, sender, sendResponse) {
    const questionContainer = document.getElementById("question-container");
    questionContainer.innerHTML = "";
    const answerContainer = document.getElementById("answer-container");
    answerContainer.innerHTML = "";
    const radioLabelsList = document.getElementById("radio-labels-list");
    radioLabelsList.innerHTML = "";


    if (request.action === "sisaWaktu") {
        const data = request.value

        if (data.questionText) {
            const questionTextElement = document.createElement("p");
            questionTextElement.innerText = data.questionText;
            questionTextElement.classList.add("font-bold", "mb-3");
            questionContainer.appendChild(questionTextElement);

            const payloadJawaban = {
                "messages": [
                    {
                        "id": "QBYV0he",
                        "content": ` if i give you this kind of question ${data.questionText} . choose the only one answer response the only one answer ${data.radioLabels.join(' ')} and i need you to response with only the right answer like
'Gaya dada'

just response like that
wrap the answer ezactly like this '#{[the correct answer]}#'

this the question ${data.questionText} and here the option ${data.radioLabels.join(' ')}
`,
                        "role": "user"
                    }
                ],
                "id": "SivX7vK",
                "previewToken": null,
                "userId": "a040eed4-fb5e-420d-b73e-5441eecac0f2",
                "codeModelMode": true,
                "agentMode": {},
                "trendingAgentMode": {},
                "isMicMode": false,
                "isChromeExt": false,
                "githubToken": null
            }

            try {
                console.log("Getting The Answer ..")
                const response = await fetch("https://blackbox.ai/api/chat", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payloadJawaban)
                });

                const responseData = await response.text();

                const answerText = document.createElement("p");
                answerText.innerText = "Answer : " + extractText(responseData);
                answerContainer.appendChild(answerText);
                answerText.classList.add("mt-6");
                console.log('Success Get The Answer: ', extractText(responseData));

                chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, { action: "selectAnswer", answer: extractText(responseData) });
                });

            } catch (error) {
                console.error('Error:', error);
            }

        }

        if (data.radioLabels) {
            const radioLabels = data.radioLabels;
            radioLabels.forEach((label, index) => {
                const listItem = document.createElement("li");
                listItem.innerText = `${label}`;
                radioLabelsList.appendChild(listItem);
            });
        }

    }
});
